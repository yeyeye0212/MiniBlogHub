#数据库扩展文件
from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()